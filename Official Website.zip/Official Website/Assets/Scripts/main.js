//This is my Javascript file!!

/*****************************************     JavaScript Validation          **********************************************/
function validateForm() {
var name =  document.getElementById('name').value;
if (name == "") {
    alert("Write down name please ");
    return false;
}
var email =  document.getElementById('email').value;
if (email == "") {
    alert("Email cannot be empty");
    return false;
} else {
    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    if(!re.test(email)){
        alert("Email format invalid"); 
        return false;
    }
}
var subject =  document.getElementById('subject').value;
if (subject == "") {
    alert("Subject cannot be empty");
    return false;
}
var message =  document.getElementById('message').value;
if (message == "") {
    alert("Message cannot be empty");
    return false;
}

document.getElementById('contact-form').submit();

}

document.getElementById('contact-form').submit();
formData = {
'name'     : $('input[name=name]').val(),
'email'    : $('input[name=email]').val(),
'subject'  : $('input[name=subject]').val(),
'message'  : $('textarea[name=message]').val()
};

formData = {
  'name'     : $('input[name=name]').val(),
  'email'    : $('input[name=email]').val(),
  'subject'  : $('input[name=subject]').val(),
  'message'  : $('textarea[name=message]').val(),
  'updates'  : $('input:checkbox[name=updates]').is(':checked')
};

formData = {
  'name'     : $('input[name=name]').val(),
  'email'    : $('input[name=email]').val(),
  'subject'  : $('input[name=subject]').val(),
  'message'  : $('textarea[name=message]').val(),
  'cmethod'  : $('input:radio[name=cmethod]:checked').val()
};

$.ajax({
url : "mail.php",
type: "POST",
data : formData,
success: function(data, textStatus, jqXHR)
{

$('#status').text(data.message);
if (data.code) //If mail was sent successfully, reset the form.
$('#contact-form').closest('form').find("input[type=text], textarea").val("");
},
error: function (jqXHR, textStatus, errorThrown)
{
$('#status').text(jqXHR);
}
});


/**********************************  3 JavaScript Website Functions      ***************************************/

//Get the button:
const mybutton = document.getElementById("myBtn");

// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    mybutton.style.display = "block";
  } else {
    mybutton.style.display = "none";
  }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
  document.body.scrollTop = 0; // For Safari
  document.documentElement.scrollTop = 0; // For Chrome, Firefox, IE and Opera
}


//Smooth Scrolling of the page
 $('.navbar a').on('click', function (e) {
   if (this.hash !== '') {
     e.preventDefault();

     const hash = this.hash;

     $('html, body')
       .animate({
         scrollTop: $(hash).offset().top
       },800);
   }
 });

//picture pop up
 $("img").on('click',function(){
   var hello = $(this).attr('data-id');
   $('.section').hide();
   $('#'+hello).show();
 });